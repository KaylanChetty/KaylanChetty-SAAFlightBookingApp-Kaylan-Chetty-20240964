/* =====================================================
   South African Airways Flight Booking System
   Run each section separately and screenshot the results
   ===================================================== */

USE master;
GO
IF DB_ID('SAA_FlightBooking') IS NOT NULL
BEGIN
    ALTER DATABASE SAA_FlightBooking SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE SAA_FlightBooking;
END
GO
CREATE DATABASE SAA_FlightBooking;
GO
USE SAA_FlightBooking;
GO

/* ---------- TASK 3 & 4: TABLES AND RELATIONSHIPS ---------- */

CREATE TABLE Airports (
    AirportID   INT IDENTITY(1,1) PRIMARY KEY,
    AirportCode CHAR(3)       NOT NULL UNIQUE,
    AirportName VARCHAR(100)  NOT NULL,
    City        VARCHAR(50)   NOT NULL,
    Country     VARCHAR(50)   NOT NULL DEFAULT 'South Africa'
);

CREATE TABLE Passengers (
    PassengerID    INT IDENTITY(1,1) PRIMARY KEY,
    FirstName      VARCHAR(50)  NOT NULL,
    LastName       VARCHAR(50)  NOT NULL,
    Email          VARCHAR(100) NOT NULL UNIQUE,
    Phone          VARCHAR(20)  NULL,
    PassportNumber VARCHAR(20)  NOT NULL UNIQUE,
    DateOfBirth    DATE         NOT NULL,
    CONSTRAINT CK_Passengers_Email CHECK (Email LIKE '%_@_%._%')
);

CREATE TABLE Flights (
    FlightID           INT IDENTITY(1,1) PRIMARY KEY,
    FlightNumber       VARCHAR(10)   NOT NULL UNIQUE,
    DepartureAirportID INT           NOT NULL,
    ArrivalAirportID   INT           NOT NULL,
    DepartureTime      DATETIME      NOT NULL,
    ArrivalTime        DATETIME      NOT NULL,
    BasePrice          DECIMAL(10,2) NOT NULL CHECK (BasePrice > 0),
    Capacity           INT           NOT NULL CHECK (Capacity > 0),
    CONSTRAINT FK_Flights_Departure FOREIGN KEY (DepartureAirportID) REFERENCES Airports(AirportID),
    CONSTRAINT FK_Flights_Arrival   FOREIGN KEY (ArrivalAirportID)   REFERENCES Airports(AirportID),
    CONSTRAINT CK_Flights_Airports  CHECK (DepartureAirportID <> ArrivalAirportID),
    CONSTRAINT CK_Flights_Times     CHECK (ArrivalTime > DepartureTime)
);

CREATE TABLE Bookings (
    BookingID     INT IDENTITY(1,1) PRIMARY KEY,
    BookingRef    VARCHAR(10)   NOT NULL UNIQUE,
    FlightID      INT           NOT NULL,
    BookingDate   DATETIME      NOT NULL DEFAULT GETDATE(),
    BookingStatus VARCHAR(20)   NOT NULL DEFAULT 'Pending'
        CHECK (BookingStatus IN ('Pending','Confirmed','Cancelled')),
    TotalAmount   DECIMAL(10,2) NOT NULL CHECK (TotalAmount >= 0),
    CONSTRAINT FK_Bookings_Flights FOREIGN KEY (FlightID) REFERENCES Flights(FlightID)
);

-- Associative table: many-to-many between Bookings and Passengers
CREATE TABLE BookingPassengers (
    BookingPassengerID INT IDENTITY(1,1) PRIMARY KEY,
    BookingID   INT NOT NULL,
    PassengerID INT NOT NULL,
    CONSTRAINT FK_BP_Bookings   FOREIGN KEY (BookingID)   REFERENCES Bookings(BookingID),
    CONSTRAINT FK_BP_Passengers FOREIGN KEY (PassengerID) REFERENCES Passengers(PassengerID),
    CONSTRAINT UQ_BP UNIQUE (BookingID, PassengerID)
);

CREATE TABLE Tickets (
    TicketID           INT IDENTITY(1,1) PRIMARY KEY,
    TicketNumber       VARCHAR(15)   NOT NULL UNIQUE,
    BookingPassengerID INT           NOT NULL UNIQUE,
    SeatNumber         VARCHAR(5)    NOT NULL,
    TravelClass        VARCHAR(20)   NOT NULL DEFAULT 'Economy'
        CHECK (TravelClass IN ('Economy','Business')),
    Price              DECIMAL(10,2) NOT NULL CHECK (Price >= 0),
    CONSTRAINT FK_Tickets_BP FOREIGN KEY (BookingPassengerID) REFERENCES BookingPassengers(BookingPassengerID)
);

CREATE TABLE Payments (
    PaymentID     INT IDENTITY(1,1) PRIMARY KEY,
    BookingID     INT           NOT NULL,
    Amount        DECIMAL(10,2) NOT NULL CHECK (Amount > 0),
    PaymentDate   DATETIME      NOT NULL DEFAULT GETDATE(),
    PaymentMethod VARCHAR(20)   NOT NULL CHECK (PaymentMethod IN ('Credit Card','Debit Card','EFT','Cash')),
    PaymentStatus VARCHAR(20)   NOT NULL DEFAULT 'Pending'
        CHECK (PaymentStatus IN ('Pending','Paid','Failed','Refunded')),
    CONSTRAINT FK_Payments_Bookings FOREIGN KEY (BookingID) REFERENCES Bookings(BookingID)
);
GO

/* ---------- TASK 6: INSERT DATA ---------- */

INSERT INTO Airports (AirportCode, AirportName, City) VALUES
('JNB','O.R. Tambo International Airport','Johannesburg'),
('CPT','Cape Town International Airport','Cape Town'),
('BFN','Bloemfontein Airport','Bloemfontein'),
('GRJ','George Airport','George');

INSERT INTO Passengers (FirstName, LastName, Email, Phone, PassportNumber, DateOfBirth) VALUES
('Themba','Dube','themba.dube@email.com','0832045511','B7021345','1987-02-14'),
('Karabo','Molefe','karabo.molefe@email.com','0714456620','B7132456','1991-06-27'),
('Elena','Fourie','elena.fourie@email.com','0825567731','B7243567','1993-10-03'),
('Imran','Hendricks','imran.hendricks@email.com','0766678842','B7354678','1980-12-19'),
('Busisiwe','Mthembu','busisiwe.mthembu@email.com','0847789953','B7465789','1996-08-08'),
('Ryan','Pillay','ryan.pillay@email.com','0738891064','B7576890','1989-05-21');

INSERT INTO Flights (FlightNumber, DepartureAirportID, ArrivalAirportID, DepartureTime, ArrivalTime, BasePrice, Capacity) VALUES
('SA101', 1, 2, '2026-12-05 07:00', '2026-12-05 09:10', 2100.00, 170),
('SA102', 2, 1, '2026-12-05 16:30', '2026-12-05 18:40', 2150.00, 170),
('SA250', 1, 3, '2026-12-06 08:15', '2026-12-06 09:20', 1250.00, 140),
('SA318', 4, 2, '2026-12-07 12:00', '2026-12-07 13:15', 1380.00, 100),
('SA477', 1, 4, '2026-12-08 10:45', '2026-12-08 12:30', 1900.00, 120);

INSERT INTO Bookings (BookingRef, FlightID, BookingStatus, TotalAmount) VALUES
('SAA2001', 1, 'Pending',   4200.00),
('SAA2002', 3, 'Confirmed', 1250.00),
('SAA2003', 4, 'Pending',   4140.00);

INSERT INTO BookingPassengers (BookingID, PassengerID) VALUES
(1,1),(1,2),(2,3),(3,4),(3,5),(3,6);

INSERT INTO Tickets (TicketNumber, BookingPassengerID, SeatNumber, TravelClass, Price) VALUES
('SAA-T-0001',1,'14C','Economy',2100.00),
('SAA-T-0002',2,'14D','Economy',2100.00),
('SAA-T-0003',3,'03A','Economy',1250.00),
('SAA-T-0004',4,'09D','Economy',1380.00),
('SAA-T-0005',5,'09E','Economy',1380.00),
('SAA-T-0006',6,'09F','Economy',1380.00);

INSERT INTO Payments (BookingID, Amount, PaymentMethod, PaymentStatus) VALUES
(1, 4200.00, 'EFT',         'Pending'),
(2, 1250.00, 'Credit Card', 'Paid'),
(3, 4140.00, 'Debit Card',  'Pending');
GO

/* ---------- TASK 7: RETRIEVE DATA ---------- */

SELECT PassengerID AS [ID], FirstName + ' ' + LastName AS [Passenger Name], Email AS [Email Address]
FROM Passengers ORDER BY LastName;

SELECT FlightNumber AS [Flight], DepartureTime AS [Departs], ArrivalTime AS [Arrives], BasePrice AS [Price (ZAR)]
FROM Flights ORDER BY DepartureTime;

SELECT BookingRef AS [Reference], BookingDate AS [Booked On], BookingStatus AS [Status], TotalAmount AS [Total]
FROM Bookings ORDER BY BookingDate DESC;

SELECT PaymentID AS [Payment], BookingID AS [Booking], Amount, PaymentMethod AS [Method], PaymentStatus AS [Status]
FROM Payments ORDER BY PaymentDate;

-- Flights departing from Johannesburg
SELECT f.FlightNumber AS [Flight], a.City AS [Arriving In], f.DepartureTime AS [Departs]
FROM Flights f
INNER JOIN Airports d ON f.DepartureAirportID = d.AirportID
INNER JOIN Airports a ON f.ArrivalAirportID = a.AirportID
WHERE d.City = 'Johannesburg'
ORDER BY f.DepartureTime;

-- Flights arriving in Cape Town
SELECT f.FlightNumber AS [Flight], d.City AS [Departing From], f.ArrivalTime AS [Arrives]
FROM Flights f
INNER JOIN Airports d ON f.DepartureAirportID = d.AirportID
INNER JOIN Airports a ON f.ArrivalAirportID = a.AirportID
WHERE a.City = 'Cape Town'
ORDER BY f.ArrivalTime;

/* ---------- TASK 8: UPDATE DATA (run SELECT before and after) ---------- */

SELECT PassengerID, Email FROM Passengers WHERE PassengerID = 1;
UPDATE Passengers SET Email = 'themba.d@newmail.com' WHERE PassengerID = 1;
SELECT PassengerID, Email FROM Passengers WHERE PassengerID = 1;

SELECT BookingID, BookingStatus FROM Bookings WHERE BookingID = 1;
UPDATE Bookings SET BookingStatus = 'Confirmed' WHERE BookingID = 1;
SELECT BookingID, BookingStatus FROM Bookings WHERE BookingID = 1;

SELECT PaymentID, PaymentStatus FROM Payments WHERE PaymentID = 1;
UPDATE Payments SET PaymentStatus = 'Paid' WHERE PaymentID = 1;
SELECT PaymentID, PaymentStatus FROM Payments WHERE PaymentID = 1;

/* ---------- TASK 9: DELETE DATA ---------- */

SELECT * FROM Bookings;
DELETE FROM Bookings WHERE BookingID = 1;
-- Expected: Msg 547, The DELETE statement conflicted with the REFERENCE
-- constraint (FK_BP_Bookings / FK_Payments_Bookings). Child rows exist.
SELECT * FROM Bookings;

-- Correct order: delete children first, then the booking
BEGIN TRANSACTION;
DELETE FROM Tickets WHERE BookingPassengerID IN (SELECT BookingPassengerID FROM BookingPassengers WHERE BookingID = 1);
DELETE FROM BookingPassengers WHERE BookingID = 1;
DELETE FROM Payments WHERE BookingID = 1;
DELETE FROM Bookings WHERE BookingID = 1;
SELECT * FROM Bookings;
ROLLBACK TRANSACTION;  -- change to COMMIT to keep the deletion

/* ---------- TASK 10: JOINS AND AGGREGATES ---------- */

-- Passenger bookings
SELECT p.FirstName + ' ' + p.LastName AS [Passenger], b.BookingRef AS [Booking], f.FlightNumber AS [Flight], b.BookingStatus AS [Status]
FROM Passengers p
INNER JOIN BookingPassengers bp ON p.PassengerID = bp.PassengerID
INNER JOIN Bookings b ON bp.BookingID = b.BookingID
INNER JOIN Flights f ON b.FlightID = f.FlightID
ORDER BY b.BookingRef;

-- Flight manifest
SELECT f.FlightNumber AS [Flight], p.FirstName + ' ' + p.LastName AS [Passenger], t.SeatNumber AS [Seat], t.TravelClass AS [Class]
FROM Flights f
INNER JOIN Bookings b ON f.FlightID = b.FlightID
INNER JOIN BookingPassengers bp ON b.BookingID = bp.BookingID
INNER JOIN Passengers p ON bp.PassengerID = p.PassengerID
LEFT JOIN Tickets t ON bp.BookingPassengerID = t.BookingPassengerID
ORDER BY f.FlightNumber, t.SeatNumber;

-- Revenue per flight (LEFT JOIN shows flights with no sales)
SELECT f.FlightNumber AS [Flight], COUNT(t.TicketID) AS [Tickets Sold], ISNULL(SUM(t.Price),0) AS [Revenue (ZAR)]
FROM Flights f
LEFT JOIN Bookings b ON f.FlightID = b.FlightID
LEFT JOIN BookingPassengers bp ON b.BookingID = bp.BookingID
LEFT JOIN Tickets t ON bp.BookingPassengerID = t.BookingPassengerID
GROUP BY f.FlightNumber
ORDER BY [Revenue (ZAR)] DESC;

-- Tickets issued per booking
SELECT b.BookingRef AS [Booking], COUNT(t.TicketID) AS [Tickets Issued]
FROM Bookings b
LEFT JOIN BookingPassengers bp ON b.BookingID = bp.BookingID
LEFT JOIN Tickets t ON bp.BookingPassengerID = t.BookingPassengerID
GROUP BY b.BookingRef;

-- Overall booking summary
SELECT b.BookingRef AS [Booking], f.FlightNumber AS [Flight], b.BookingStatus AS [Booking Status],
       COUNT(DISTINCT bp.PassengerID) AS [Passengers], b.TotalAmount AS [Total],
       ISNULL(SUM(DISTINCT pay.Amount),0) AS [Paid/Billed], MAX(pay.PaymentStatus) AS [Payment Status]
FROM Bookings b
INNER JOIN Flights f ON b.FlightID = f.FlightID
LEFT JOIN BookingPassengers bp ON b.BookingID = bp.BookingID
LEFT JOIN Payments pay ON b.BookingID = pay.BookingID
GROUP BY b.BookingRef, f.FlightNumber, b.BookingStatus, b.TotalAmount;
