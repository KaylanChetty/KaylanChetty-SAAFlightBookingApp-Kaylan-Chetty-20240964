using Microsoft.Data.SqlClient;

// Change Server to match your instance (e.g. localhost, .\SQLEXPRESS, (localdb)\MSSQLLocalDB)
string connectionString =
    "Server=(localdb)\\MSSQLLocalDB;Database=SAA_FlightBooking;Trusted_Connection=True;TrustServerCertificate=True;";

try
{
    using var connection = new SqlConnection(connectionString);
    connection.Open();
    Console.WriteLine("Connection to SAA_FlightBooking established successfully!\n");

    string sql = "SELECT PassengerID, FirstName, LastName, Email, Phone, PassportNumber FROM Passengers";
    using var command = new SqlCommand(sql, connection);
    using var reader = command.ExecuteReader();

    Console.WriteLine($"{"ID",-4}{"First Name",-12}{"Last Name",-12}{"Email",-32}{"Phone",-14}{"Passport"}");
    Console.WriteLine(new string('-', 85));

    while (reader.Read())
    {
        Console.WriteLine($"{reader["PassengerID"],-4}{reader["FirstName"],-12}{reader["LastName"],-12}" +
                          $"{reader["Email"],-32}{reader["Phone"],-14}{reader["PassportNumber"]}");
    }
}
catch (SqlException ex)
{
    Console.WriteLine("Database error: " + ex.Message);
}
